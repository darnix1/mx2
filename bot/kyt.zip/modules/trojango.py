from kyt import *

@bot.on(events.CallbackQuery(data=b'trojan-go'))
async def nob(event):
    async def nob_(event):
        inline = [
            [Button.inline(" CREAR TROJAN-GO ","create-trgo"),
             Button.inline(" VER USUARIOS ","cek-trgo")],
            [Button.inline(" ELIMINAR USUARIO ","delete-trgo"),
             Button.inline(" RENOVAR USUARIO ","renew-trgo")],
            [Button.inline("‹ VOLVER ›","menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        tgo = f' cat /etc/trojan-go/trgo | grep "###" | wc -l'
        trgo = subprocess.check_output(tgo, shell=True).decode("ascii")
        msg = f"""
🧿───────────────────🧿
**PANEL TROJAN-GO**
🧿───────────────────🧿
` Servicio  :` `TROJAN-GO`
` Cuentas  :` `{trgo.strip()}` __activas__
` Host     :` `{DOMAIN}`
` ISP      :` `{z["isp"]}`
` País     :` `{z["country"]}`
** @darnix0**
🧿───────────────────🧿
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await nob_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'create-trgo'))
async def create_trgo(event):
    async def create_trgo_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
**✨ El nombre debe contener:
 Mayúsculas, minúsculas y números**
**✨ Sin espacios**
**✨ Nombres únicos**
**✨ Bot: @darnix0**

**✨ Ingrese su nombre de usuario:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**✨ Ingrese días de expiración:**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            cmd = f'printf "%s\n" "1" "{user}" "{exp}" | m-trgo | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» CUENTA CREADA**
**» LISTO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_trgo_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

        
@bot.on(events.CallbackQuery(data=b'delete-trgo'))
async def delete_trgo(event):
    async def delete_trgo_(event):
        await event.edit(f"""
Función disponible próximamente :)
""",buttons=[[Button.inline(" Volver ","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_trgo_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'renew-trgo'))
async def renew_trgo(event):
    async def renew_trgo_(event):
        await event.edit(f"""
Función disponible próximamente :)
""",buttons=[[Button.inline(" Volver ","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_trgo_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'cek-trgo'))
async def cek_trgo(event):
    async def cek_trgo_(event):
        await event.edit(f"""
Función disponible próximamente :)
""",buttons=[[Button.inline(" Volver ","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_trgo_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)