from kyt import *

@bot.on(events.CallbackQuery(data=b'noobz'))
async def nob(event):
    async def nob_(event):
        inline = [
            [Button.inline(" CREAR NOOBZ ","create-noobz"),
             Button.inline(" VER USUARIOS ","cek-noobz")],
            [Button.inline(" ELIMINAR USUARIO ","delete-noobz"),
             Button.inline(" DESBLOQUEAR USUARIO ","unblock-noobz")],
            [Button.inline(" BLOQUEAR USUARIO ","lock-noobz"),
             Button.inline("‹ VOLVER ›","menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        noob = f' cat /etc/xray/noob | grep "###" | wc -l'
        noobz = subprocess.check_output(noob, shell=True).decode("ascii")
        msg = f"""
🧿───────────────────🧿
   **PANEL NOOBZVPNS**
🧿───────────────────🧿
` NO DISPONIBLE:` `NOOBZVPNS`
` Total  :` `{noobz.strip()}` __cuentas__
` Host   :` `{DOMAIN}`
` ISP    :` `{z["isp"]}`
` País:` `{z["country"]}`
** @darnix0**
🧿───────────────────🧿
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await nob_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'create-noobz'))
async def create_noobz(event):
    async def create_noobz_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
**✨ El nombre debe contener:
 Mayúsculas, minúsculas y números**
**✨ Sin espacios**
**✨ Nombres únicos**
**✨ Bot: @darnix0**

**✨ Ingrese nombre de usuario:**
/cancel Volver al Menú
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as pw:
                await event.respond(f"""
**✨ Ingrese contraseña:**
""")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**✨ Ingrese días de expiración:**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            async with bot.conversation(chat) as pw2:
                await event.respond(f"""
**✨ Ingrese límite de IP:**
""")
                pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw2 = (await pw2).raw_text
            cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{pw2}" | addnoobz | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**🧿───────────────────🧿**
`•TCP•`
**🧿───────────────────🧿**
**» Host:** `{DOMAIN}`
**» Usuario:** `{user}`
**» Contraseña:** `{pw}`
**» Límite IP:** `{pw2}`
**🧿───────────────────🧿**
**» PUERTO TCP_STD     :** `8080`
**» PUERTO TCP_SSL    :** `8443`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
`GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]`
**🧿───────────────────🧿**
**» Expiración:** `{exp}` Días
**» 🛂@darnix0**
**🧿───────────────────🧿**
""")
            await event.respond(f"""
**» CUENTA CREADA**
**» LISTO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_noobz_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'delete-noobz'))
async def delete_noobz(event):
    async def delete_noobz_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/noob | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS A ELIMINAR**
{z}
**✨ Ingrese nombre de usuario:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'noobzvpns --remove-user {user}'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» USUARIO ELIMINADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_noobz_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'lock-noobz'))
async def lock_noobz(event):
    async def lock_noobz_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/noob | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS A BLOQUEAR**
{z}
**✨ Ingrese nombre de usuario:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'noobzvpns --block-user {user}'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» USUARIO BLOQUEADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await lock_noobz_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'unblock-noobz'))
async def unblock_noobz(event):
    async def unblock_noobz_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/noob | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS A DESBLOQUEAR**
{z}
**✨ Ingrese nombre de usuario:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'noobzvpns --block-user {user}'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» USUARIO DESBLOQUEADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await unblock_noobz_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'cek-noobz'))
async def login_noobz(event):
    async def login_noobz_(event):
        cmd = 'cek-noobz'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.edit(f"""
** USUARIOS NOOBZ CONECTADOS**
{z}
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await login_noobz_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)