from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-trojan'))
async def delete_trojan(event):
    async def delete_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS PARA ELIMINAR**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "4" "{user}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-trojan'))
async def renew_trojan(event):
    async def renew_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS PARA RENOVAR**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**✨ Ingrese nueva fecha de expiración (días):**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» ÉXITO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)


#limit
@bot.on(events.CallbackQuery(data=b'limit7-trojan'))
async def limit_trojan(event):
    async def limit_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ CAMBIAR LÍMITE DE USUARIO**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**✨ Ingrese nuevo límite de IP para login:**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            async with bot.conversation(chat) as pw:
                await event.respond(f"""
**✨ Ingrese nueva cuota de usuario:**
""")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» CAMBIO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await limit_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-trojan'))
async def akun_trojan(event):
    async def akun_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/config.json | grep '^#trg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ VERIFICAR CONFIGURACIÓN DE USUARIO**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "6" "{user}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» VERIFICACIÓN EXITOSA**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await akun_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
        
#restore
@bot.on(events.CallbackQuery(data=b'restore7-trojan'))
async def restore_trojan(event):
    async def restore_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/trojan/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE CUENTAS PARA RESTAURAR**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**✨ Ingrese fecha de expiración (días):**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            async with bot.conversation(chat) as pw:
                await event.respond(f"""
**✨ Ingrese nuevo límite de IP para login:**
""")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            async with bot.conversation(chat) as pw2:
                await event.respond(f"""
**✨ Ingrese nueva cuota de usuario:**
""")
                pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw2 = (await pw2).raw_text
            cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» CAMBIO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await restore_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)


#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-trojan'))
async def loginip_trojan(event):
    async def loginip_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/trojan/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS CON MULTI LOGIN IP**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "9" "{user}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» DESBLOQUEO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await loginip_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-trojan'))
async def logingb_trojan(event):
    async def logingb_trojan_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/trojan/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**✨ LISTA DE USUARIOS CON LÍMITE DE CUOTA**
{z}
**✨ Ingrese su número:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "10" "{user}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» DESBLOQUEO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await logingb_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
#CRATE trojan
@bot.on(events.CallbackQuery(data=b'create7-trojan'))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
**✨ Ingrese su nombre de usuario:**
/cancel Volver al MENÚ
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**✨ Ingrese fecha de expiración (días):**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            async with bot.conversation(chat) as pw:
                await event.respond(f"""
**✨ Ingrese límite de IP para login:**
""")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            async with bot.conversation(chat) as pw2:
                await event.respond(f"""
**✨ Ingrese cuota de usuario:**
""")
                pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw2 = (await pw2).raw_text
            cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

# TRIAL trojan
@bot.on(events.CallbackQuery(data=b'trial7-trojan'))
async def trial_trojan(event):
    async def trial_trojan_(event):
        async with bot.conversation(chat) as exp:
            await event.edit(f"""
**✨ Ingrese tiempo (minutos):**
/cancel Volver al MENÚ
""")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        per = "/cancel"
        if exp == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" {2} "{exp}" | m-trojan | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True).decode("utf-8")
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-trojan'))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'bot-cek-tr'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.edit(f"""
**✨ USUARIOS TROJAN CONECTADOS**
{z}
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await cek_trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline(" DESBLOQUEAR LOGIN ","loginip7-trojan"),
             Button.inline(" DESBLOQUEAR CUOTA ","logingb7-trojan")],
            [Button.inline("‹ Atrás ›","trojan")]
        ]
        await event.edit(buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline(" Prueba ","trial7-trojan"),
             Button.inline(" Crear ","create7-trojan"),
             Button.inline(" Conectados ","cek7-trojan")],
            [Button.inline(" Eliminar ","delete7-trojan"),
             Button.inline(" Desbloquear ","login7-trojan"),
             Button.inline(" Límite ","limit7-trojan")],
            [Button.inline(" Renovar","renew7-trojan"),
             Button.inline(" Restaurar ","restore7-trojan"),
             Button.inline(" Cuenta ","akun7-trojan")],
            [Button.inline("‹ VOLVER ›","menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        vm = f' cat /etc/xray/config.json | grep "#trg" | wc -l'
        vms = subprocess.check_output(vm, shell=True).decode("ascii")
        msg = f"""
🧿───────────────────🧿
         **PANEL MENÚ TROJAN**
🧿───────────────────🧿
` Total Acc:` `{vms.strip()}` __cuentas__
` Host     :` `{DOMAIN}`
` ISP      :` `{z["isp"]}`
` País     :` `{z["country"]}`
🧿───────────────────🧿
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)