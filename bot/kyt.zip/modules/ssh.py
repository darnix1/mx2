from kyt import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def create_ssh_(event):
        async with bot.conversation(chat) as user:
            await event.edit(f"""
**CREAR NOMBRE DE USUARIO SIN ESPACIOS**
/cancel Para volver
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as pw:
                await event.respond(f"""
**INGRESE CONTRASEÑA DE LA CUENTA:**
""")
                pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw = (await pw).raw_text
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**INGRESE EXPIRACIÓN DE LA CUENTA (Días):**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            async with bot.conversation(chat) as pw2:
                await event.respond(f"""
**INGRESE LÍMITE DE IP PARA LOGIN:**
""")
                pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                pw2 = (await pw2).raw_text
            cmd = f'printf "%s\n" "1" "{user}" "{pw}" "{exp}" "{pw2}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await create_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    async def delete_ssh_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**LISTA DE TODOS LOS USUARIOS**
{z}
**INGRESE NÚMERO:**
/cancel Para volver
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "4" "{user}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await delete_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limit_ssh(event):
    async def limit_ssh_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**CAMBIAR LÍMITE DE USUARIO**
{z}
**INGRESE NÚMERO:**
/cancel Para volver
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**Ingrese nuevo límite de IP para login:**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            cmd = f'printf "%s\n" "7" "{user}" "{exp}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» CAMBIO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await limit_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        async with bot.conversation(chat) as exp:
            await event.edit(f"""
**Ingrese minutos (solo números):**
/cancel Para volver
""")
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text
        per = "/cancel"
        if exp == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" {2} "{exp}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)
        
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        cmd = 'bot-cek-login-ssh'.strip()
        x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        print(x)
        z = subprocess.check_output(cmd, shell=True).decode("utf-8")
        await event.edit(f"""
** USUARIOS SSH CONECTADOS **
{z}
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await login_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)


@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
    async def renew_ssh_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/ssh | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**LISTA DE USUARIOS PARA RENOVAR**
{z}
**INGRESE NÚMERO:**
/cancel Para volver
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            async with bot.conversation(chat) as exp:
                await event.respond(f"""
**INGRESE NUEVA FECHA DE EXPIRACIÓN (días):**
""")
                exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp).raw_text
            cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await renew_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/sshx/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**LISTA DE USUARIOS CON MULTI LOGIN**
{z}
**INGRESE NÚMERO:**
/cancel Para volver
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "9" "{user}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» DESBLOQUEO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await login_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'akun-ssh'))
async def akun_ssh(event):
    async def akun_ssh_(event):
        async with bot.conversation(chat) as user:
            cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
            x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
            print(x)
            z = subprocess.check_output(cmd2, shell=True).decode("ascii")
            await event.edit(f"""
**VERIFICAR CONFIGURACIÓN DE USUARIO**
{z}
**INGRESE NÚMERO:**
/cancel Para volver
""")
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        per = "/cancel"
        if user == per:
            await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
        else:
            cmd = f'printf "%s\n" "6" "{user}" | m-sshovpn | sleep 2 | exit'
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"""
**» VERIFICACIÓN EXITOSA**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await akun_ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_(event):
        inline = [
[Button.inline(" Prueba ","trial-ssh"),
Button.inline(" Crear ","create-ssh"),
Button.inline(" Conectados ","cek-ssh")],
[Button.inline(" Eliminar ","delete-ssh"),
Button.inline(" Desbloquear ","login-ssh"),
Button.inline(" Límite ","limit-ssh")],
[Button.inline(" Renovar","renew-ssh"),
Button.inline(" Cuenta ","akun-ssh"),
Button.inline("‹ VOLVER ›","menu")]]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
        ssh = subprocess.check_output(sh, shell=True).decode("ascii")
        msg = f"""
┌──────────────────────┐
  ⚡   DARNIX PREMIUM   ⚡
└──────────────────────┘
  
   🌌 **Panel SSH**

` Total   :` `{ssh.strip()}` __cuentas__
` Host    :` `{DOMAIN}`
` ISP     :` `{z["isp"]}`
` País    :` `{z["country"]}`
└──────────────────────┘
"""
        await event.edit(msg,buttons=inline)
    sender = await event.get_sender()
    a = valid(str(sender.id))
    if a == "true":
        await ssh_(event)
    else:
        await event.answer("Acceso Denegado",alert=True)