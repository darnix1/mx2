from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def delete_vmess(event):
	async def delete_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LISTA DE TODOS LOS USUARIOS**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vmess'))
async def renew_vmess(event):
	async def renew_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LISTA DE TODOS LOS USUARIOS**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**Ingrese su nueva fecha de expiración (días):**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)


#limit
@bot.on(events.CallbackQuery(data=b'limit7-vmess'))
async def limit_vmess(event):
	async def limit_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**CAMBIAR LÍMITE DE USUARIO**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**Ingrese su nuevo límite de IP para login:**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**Ingrese su nueva cuota de usuario:**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» CAMBIO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-vmess'))
async def akun_vmess(event):
	async def akun_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**VERIFICAR CONFIGURACIÓN DE USUARIO**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» VERIFICACIÓN EXITOSA**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
		
		
#restore
@bot.on(events.CallbackQuery(data=b'restore7-vmess'))
async def restore_vmess(event):
	async def restore_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LISTA DE CUENTAS PARA RESTAURAR**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**Ingrese su fecha de expiración (días):**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**Ingrese su nuevo límite de IP para login:**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**Ingrese su nueva cuota de usuario:**
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» CAMBIO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)


#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-vmess'))
async def loginip_vmess(event):
	async def loginip_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LISTA DE USUARIOS CON MULTI LOGIN IP**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» DESBLOQUEO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await loginip_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
		
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-vmess'))
async def logingb_vmess(event):
	async def logingb_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LISTA DE USUARIOS CON LÍMITE DE CUOTA**
{z}
**Ingrese su número:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			cmd = f'printf "%s\n" "10" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» DESBLOQUEO EXITOSO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await logingb_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
		
#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
	async def create_vmess_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
**Ingrese nombre de usuario:**
/cancel Para volver
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**Ingrese su fecha de expiración (días):**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**Ingrese su límite de IP para login:**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""
**Ingrese su cuota de usuario:**
""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
	async def trial_vmess_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**Ingrese sus minutos (solo números):**
/cancel Para volver
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» CANCELADO**
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True).decode("utf-8")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vmess'))
async def cek_vmess(event):
	async def cek_vmess_(event):
		cmd = 'bot-cek-ws'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
**USUARIOS VMESS CONECTADOS**
{z}
""",buttons=[[Button.inline("‹ Menú Principal ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" DESBLOQUEAR LOGIN ","loginip7-vmess"),
Button.inline(" DESBLOQUEAR CUOTA ","logingb7-vmess")],
[Button.inline("‹ Atrás ›","vmess")]]
		await event.edit(buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
	async def vmess_(event):
		inline = [
[Button.inline(" Prueba ","trial7-vmess"),
Button.inline(" Crear ","create7-vmess"),
Button.inline(" Conectados ","cek7-vmess")],
[Button.inline(" Eliminar ","delete7-vmess"),
Button.inline(" Desbloquear ","login7-vmess"),
Button.inline(" Límite ","limit7-vmess")],
[Button.inline(" Renovar","renew7-vmess"),
Button.inline(" Restaurar ","restore7-vmess"),
Button.inline(" Cuenta ","akun7-vmess")],
[Button.inline("‹ VOLVER ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		msg = f"""
🧿───────────────────🧿
          **PANEL MENÚ VMESS**
🧿───────────────────🧿
` Total   :` `{vms.strip()}` __cuentas__
` Host    :` `{DOMAIN}`
` ISP     :` `{z["isp"]}`
` País    :` `{z["country"]}`
🧿───────────────────🧿
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vmess_(event)
	else:
		await event.answer("Acceso Denegado",alert=True)